package com.grupo5.paturistear_v01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.grupo5.paturistear_v01.ADO.UsuarioADO;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String usuario = "usuario";
        String clave = "123";
        EditText txtEmail = (EditText) findViewById(R.id.editTextTextEmailAddress);
        EditText txtClave = (EditText) findViewById(R.id.editTextTextPassword);
        Button btnAcceder = (Button) findViewById(R.id.button);

        btnAcceder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String usuarioIngresado = txtEmail.getText().toString();
                String claveIngresada = txtClave.getText().toString();

                UsuarioADO us = new UsuarioADO(view.getContext());

                if(us.verificarUsuario(usuarioIngresado, claveIngresada))
                {
                    //Crear objeto usuario
                    Intent i = new Intent(view.getContext(), Menu.class);
                    i.putExtra("nombre", "Roberto Ramirez");
                    i.putExtra("email", "roberto@gmail.com");
                    startActivity(i);
                }
            }
        });
    }
}