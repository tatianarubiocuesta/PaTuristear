package com.grupo5.paturistear_v01;

import android.os.Bundle;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import com.grupo5.paturistear_v01.adapters.EjemploSpinnerAdapter;
import com.grupo5.paturistear_v01.ADO.SitioADO;
import com.grupo5.paturistear_v01.modelos.Sitio;

import java.util.ArrayList;

public class semana4_spinneracapter extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_semana4_spinneracapter);

        SitioADO db = new SitioADO(this);
        ArrayList<Sitio> sitios = db.listar();

        Spinner spEjemplo = (Spinner) findViewById(R.id.semana4_spinneradapter);
        EjemploSpinnerAdapter adaptador = new EjemploSpinnerAdapter(sitios);
        spEjemplo.setAdapter(adaptador);

    }
}