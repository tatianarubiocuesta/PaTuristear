package com.grupo5.paturistear_v01.adapters;

import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import com.grupo5.paturistear_v01.R;
import com.grupo5.paturistear_v01.ADO.SitioADO;
import com.grupo5.paturistear_v01.clases.Mensajes;
import com.grupo5.paturistear_v01.modelos.Sitio;
import com.grupo5.paturistear_v01.EditarSitio;
import com.grupo5.paturistear_v01.VerSitio;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class Sitios_RecyclerView extends RecyclerView.Adapter<Sitios_RecyclerView.ViewModelRegistro> {

    ArrayList<Sitio> datos;

    public Sitios_RecyclerView(ArrayList<Sitio> datos) {
        this.datos = datos;
    }

    @NonNull
    @Override
    public ViewModelRegistro onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_item, null, false);
        return new ViewModelRegistro(vista);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewModelRegistro holder, int position) {
        holder.asignarRegistros(datos.get(position));
    }

    @Override
    public int getItemCount() {
        return datos.size();
    }

    public class ViewModelRegistro extends RecyclerView.ViewHolder {

        int id;
        TextView txtNombre;
        TextView txtDescripcion;

        public ViewModelRegistro(@NonNull View itemView) {
            super(itemView);

            txtNombre = (TextView) itemView.findViewById(R.id.recycleritem_nombre);
            txtDescripcion = (TextView) itemView.findViewById(R.id.recycleritem_descripcion);
            ImageButton btnEditar = (ImageButton) itemView.findViewById(R.id.recycleritem_btnEditar);
            ImageButton btnEliminar = (ImageButton) itemView.findViewById(R.id.recycleritem_btnEliminar);

            btnEliminar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    new Mensajes(view.getContext()).confirm("Confirmación", "¿Realmente desea eliminar el registro?", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    SitioADO dbsitio = new SitioADO(view.getContext());
                                    if(dbsitio.eliminar(id))
                                        new Mensajes(view.getContext()).alert("Registro eliminado", "Se ha eliminado el registro correctamente.");
                                    else
                                        new Mensajes(view.getContext()).alert("Error", "Se ha producido un error al intentar eliminar el registro.");

                                    ((VerSitio) view.getContext()).recreate();
                                }
                            },
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    new Mensajes(view.getContext()).alert("Proceso cancelado", "Se ha cancelado el proceso.");
                                }
                            });
                }
            });

            btnEditar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent in = new Intent(view.getContext(), EditarSitio.class);
                    in.putExtra("id", id);
                    view.getContext().startActivity(in);
                }
            });

        }

        public void asignarRegistros(Sitio registro)
        {
            txtNombre.setText(registro.getNombre());
            txtDescripcion.setText(registro.getDescripcion());
            id = registro.getId();
        }
    }
}
