package com.grupo5.paturistear_v01;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.grupo5.paturistear_v01.adapters.EjemploListAdapter;
import com.grupo5.paturistear_v01.ADO.SitioADO;
import com.grupo5.paturistear_v01.modelos.Sitio;

import java.util.ArrayList;

public class semana4_listadapterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_semana4_listadapter);

        ListView lista = (ListView) findViewById(R.id.semana4_listadapter);
        SitioADO registros = new SitioADO(this);
        ArrayList<Sitio> sitios = registros.listar();

        String[] vectorSitios = new String[sitios.size()];
        for(int i=0;i<sitios.size();i++)
            vectorSitios[i] = sitios.get(i).getNombre();


        EjemploListAdapter adaptador = new EjemploListAdapter(vectorSitios);
        lista.setAdapter(adaptador);


    }
}