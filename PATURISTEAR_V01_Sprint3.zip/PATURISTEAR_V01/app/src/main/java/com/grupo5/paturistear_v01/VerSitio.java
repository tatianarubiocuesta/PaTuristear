package com.grupo5.paturistear_v01;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.grupo5.paturistear_v01.adapters.Sitios_RecyclerView;
import com.grupo5.paturistear_v01.ADO.SitioADO;
import com.grupo5.paturistear_v01.modelos.Sitio;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class VerSitio extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_sitio);

        refrescarLista();

        FloatingActionButton btnAgregar = (FloatingActionButton) findViewById(R.id.versitios_btnAgregar);
        btnAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(view.getContext(), InsertarSitio.class);
                startActivity(i);
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        refrescarLista();
    }

    private void refrescarLista()
    {
        RecyclerView rcvSitios = (RecyclerView) findViewById(R.id.versitios_recyclerview);
        rcvSitios.setLayoutManager(new LinearLayoutManager(this));

        SitioADO db = new SitioADO(this);
        ArrayList<Sitio> sitios = db.listar();

        Sitios_RecyclerView adaptador = new Sitios_RecyclerView(sitios);
        rcvSitios.setAdapter(adaptador);
    }
}