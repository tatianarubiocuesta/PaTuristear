package com.grupo5.paturistear_v01.ado;

import com.grupo5.paturistear_v01.ADO.UsuarioADO;

import junit.framework.TestCase;

public class UsuarioADOTest extends TestCase {

    public void testVerificarUsuario() {
        UsuarioADO us = new UsuarioADO(null);
        boolean resultado = us.verificarUsuario("usuario", "123");
        assertEquals(true, resultado);
    }

}