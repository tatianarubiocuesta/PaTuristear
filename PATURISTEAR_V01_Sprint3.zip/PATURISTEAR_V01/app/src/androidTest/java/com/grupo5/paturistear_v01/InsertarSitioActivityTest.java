package com.grupo5.paturistear_v01;

import junit.framework.TestCase;

public class InsertarSitioActivityTest extends TestCase {

    public void testValidarCamposVacios() {
        boolean resultado = InsertarSitio.validarCamposVacios("Luisa","Ramirez", 10,15);
        assertEquals(true, resultado);
    }
}